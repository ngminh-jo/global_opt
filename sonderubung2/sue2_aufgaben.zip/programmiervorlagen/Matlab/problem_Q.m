function [] = problem_Q(xk,lamb,sigma)

end