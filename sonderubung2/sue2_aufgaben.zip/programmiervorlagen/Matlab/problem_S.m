function [] = problem_S(xk,dk)

end